Textures come from public domain textures from unfinished game "Golgotha" by Crack.com .
Now on http://opengameart.org/ (search for "golgotha"), like http://opengameart.org/node/7591 .
